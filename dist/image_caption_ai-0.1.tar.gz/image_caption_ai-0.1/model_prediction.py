import os


class CustomModelPrediction(object):
    def __init__(self, model):
        self._model = model

    def predict(self, instance, **kwargs):
        caption_str = self._model(instance)
        return caption_str

    @classmethod
    def from_path(cls, model_dir):
        from caption_custom import Caption

        model_path = os.path.join(model_dir, 'model.tar')
        embedding_path = os.path.join(model_dir, 'embeddings.json')

        caption = Caption(model_path, embedding_path)

        return cls(caption)